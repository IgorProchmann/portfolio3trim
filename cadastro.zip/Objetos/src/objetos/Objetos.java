package objetos;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Objetos {

    public static void main(String[] args) {
        //cadastraPessoa();
        cadastraAluno();
    }
    public static void cadastraPessoa() {
        int gnt = Integer.parseInt(JOptionPane.showInputDialog("Quantas pessoas deseja cadastras?"));
        ArrayList<Pessoa> lista = new ArrayList<> ();
        for(int i = 0; i < gnt; i++){
            String nome = (JOptionPane.showInputDialog("Digite o nome: " ));
            int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade de ; "+nome));
            String cpf = (JOptionPane.showInputDialog("Digite o CPF de: " +nome));
            Pessoa p = new Pessoa(nome, idade, cpf);
            lista.add(p);
        }
         for(Pessoa p:lista){
            JOptionPane.showMessageDialog(null,"Nome: "+p.getNome()+
             "\nIdade: "+p.getIdade()+"\nCPF: "+p.getCpf());
        }
    }
    public static void cadastraAluno() {
        int gnt = Integer.parseInt(JOptionPane.showInputDialog("Quantos alunos deseja cadastras?"));
        ArrayList<Aluno> lista = new ArrayList<>();
        for (int i = 0; i < gnt; i++) {
            String nome = (JOptionPane.showInputDialog("Digite o nome: "));
            String Matricula = (JOptionPane.showInputDialog("Digite a Matricula: "));
            int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade de " + nome));
            String cpf = (JOptionPane.showInputDialog("Digite o CPF de: " + nome));
            Aluno a = new Aluno(nome, idade, cpf, Matricula);
            lista.add(a);
        }
        for (Aluno a : lista) {
            JOptionPane.showMessageDialog(null, "Nome: " + a.getNome()
                    + "\nIdade: " + a.getIdade() + "\nCPF: " + a.getCpf()+"\nMatrícula: "+ a.getMatricula());
        }
    }

    
}
